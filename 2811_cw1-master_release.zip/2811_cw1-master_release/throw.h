#ifndef THROW_H
#define THROW_H

#include "cave.h"
#include "command.h"

class Throw : public Command
{
public:
    Throw() : Command("throw") {}
    void fire(Cave& c, string userCommand);
};

#endif // THROW_H

