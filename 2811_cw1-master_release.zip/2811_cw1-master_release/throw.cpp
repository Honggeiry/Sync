#include "throw.h"
#include "coin.h"
#include "mushroom.h"

#include <iostream>


void Throw::fire(Cave& c, string userCommand)
{
    string arguments = tail(userCommand); // Extract the arguments

    // Split the arguments into object and direction
    size_t spacePos = arguments.find(' ');
    if (spacePos == string::npos)
    {
        cerr << "Invalid throw command. Usage: throw <object> <direction>" << endl;
        return;
    }

    string object = arguments.substr(0, spacePos);
    string direction = arguments.substr(spacePos + 1);

    // Get Tom's current location
    int tomX = c.getTom()->getX();
    int tomY = c.getTom()->getY();

    // Calculate the new location based on the direction
    int newTomX = tomX;
    int newTomY = tomY;

    if (direction == "north")
        newTomY--;
    else if (direction == "south")
        newTomY++;
    else if (direction == "east")
        newTomX++;
    else if (direction == "west")
        newTomX++;
    else
    {
        cerr << "Invalid direction. Use north, south, east, or west." << endl;
        return;
    }

    // Check if the new location is within the bounds
    if (newTomX < 0 || newTomY < 0 || newTomX >= c.getWidth() || newTomY >= c.getHeight())
    {
        cerr << "Can't throw the object outside the cave." << endl;
        return;
    }

    // Check if the new location is blocking
    if (c.getMap()[newTomX][newTomY]->isBlocking())
    {
        cerr << "Something is blocking the way. Can't throw the object there." << endl;
        return;
    }

    // Create the object and add it to the new location
    Location* newLocation = c.getMap()[newTomX][newTomY];
    if (object == "coin")
        newLocation->add(new Coin());
    else if (object == "mushroom")
        newLocation->add(new Mushroom());
    else
    {
        cerr << "Invalid object. Use coin or mushroom." << endl;
        return;
    }

    cout << "Threw a " << object << " " << direction << "." << endl;
}
