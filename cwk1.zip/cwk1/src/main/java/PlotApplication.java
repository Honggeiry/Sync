import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import java.io.FileNotFoundException;


/**
 * JavaFX application to plot elevations of a GPS track, for
 * the Advanced task of COMP1721 Coursework 1.
 *
 * @author Hongge Cui
 */
public class PlotApplication extends Application {
  // OPTIONAL: Implement the elevation plotting application here
  @Override
  public void start(Stage stage) {
    if (getParameters().getRaw().size() == 0) {
      System.err.println("Error: no filename provided");
      System.exit(0);
    }

    String filename = getParameters().getRaw().get(0);

    try {
      Track track = new Track(filename);

      stage.setTitle("Elevation Plot");

      final NumberAxis xAxis = new NumberAxis();
      final NumberAxis yAxis = new NumberAxis();
      xAxis.setLabel("Distance (m)");
      yAxis.setLabel("Elevation (m)");

      final LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
      lineChart.setTitle("Elevation Plot");

      XYChart.Series<Number, Number> series = new XYChart.Series<>();
      series.setName(filename);

      double distance = 0;
      Point prevPoint = null;
      for (int i = 0; i < track.size(); i++) {
        Point currPoint = track.get(i);
        if (prevPoint != null) {
          distance += Point.greatCircleDistance(prevPoint, currPoint);
        }
        prevPoint = currPoint;
        series.getData().add(new XYChart.Data<>(distance, currPoint.getElevation()));
      }

      Scene scene = new Scene(lineChart, 800, 600);
      // hide data points
      lineChart.setCreateSymbols(false);
      lineChart.getData().add(series);

      stage.setScene(scene);
      stage.show();

    } catch (FileNotFoundException e) {
      System.err.println("Error: file not found - " + filename);
      System.exit(-1);
    } catch (GPSException e) {
      System.err.println("Error: " + e.getMessage());
      System.exit(-1);
    }
  }
  public static void main(String[] args) {
    launch(args);
  }
}
