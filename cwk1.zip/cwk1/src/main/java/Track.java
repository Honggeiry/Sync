import java.io.File;
import java.io.FileNotFoundException;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Represents a point in space and time, recorded by a GPS sensor.
 *
 * @author Hongge Cui
 */
public class Track {
  private List<Point> points;

  // TODO: Create a stub for the constructor
  public Track() {}

  public Track(String filename) throws FileNotFoundException {
    points = new ArrayList<>();
    readFile(filename);
  }

  // TODO: Create a stub for readFile()
  public void readFile(String filename) throws FileNotFoundException {
    Scanner input = new Scanner(new File(filename));
    input.useDelimiter(",|\n");

    if (points == null) {
      points = new ArrayList<>();
    }

    //clear old data if exists
    points.clear();

    //read the first title line
    input.nextLine();

    while (input.hasNext()) {
      String line = input.nextLine();
      String[] parts = line.split(",");
      if (parts.length < 4) {
        throw new GPSException("Data file has fewer than 4 columns: " + line);
      }
      ZonedDateTime time = ZonedDateTime.parse(parts[0]);
      double longitude = Double.parseDouble(parts[1]);
      double latitude = Double.parseDouble(parts[2]);
      double elevation = Double.parseDouble(parts[3]);
      if (longitude < Point.getMinLongitude() || longitude > Point.getMaxLongitude()) {
        throw new GPSException("Inappropriate longitude in line: " + line);
      }
      if (latitude < Point.getMinLatitude() || latitude > Point.getMaxLatitude()) {
        throw new GPSException("Inappropriate latitude in line: " + line);
      }
      points.add(new Point(time, longitude, latitude, elevation));
    }
  }

  // TODO: Create a stub for add()
  public void add(Point point) {
    if (points == null) {
      points = new ArrayList<>();
    }
    points.add(point);
  }

  // TODO: Create a stub for get()
  public Point get(int index) {
    if (points == null) {
      points = new ArrayList<>();
    }
    if (index < 0 || index > points.size() - 1) {
      throw new GPSException("Inappropriate value!");
    }
    return points.get(index);
  }

  // TODO: Create a stub for size()
  public int size() {
    if (points == null) {
      points = new ArrayList<>();
    }
    return points.size();
  }

  // TODO: Create a stub for lowestPoint()
  public Point lowestPoint() {
    if (points == null) {
      throw new GPSException("No data in the track!");
    }
    Point minPoint = null;
    double minElevation = Double.POSITIVE_INFINITY;
    for (Point p : points) {
      if (p.getElevation() < minElevation) {
        minElevation = p.getElevation();
        minPoint = p;
      }
    }
    return minPoint;
  }

  // TODO: Create a stub for highestPoint()
  public Point highestPoint() {
    if (points == null) {
      throw new GPSException("No data in the track!");
    }
    Point maxPoint = null;
    double maxElevation = Double.NEGATIVE_INFINITY;
    for (Point p : points) {
      if (p.getElevation() > maxElevation) {
        maxElevation = p.getElevation();
        maxPoint = p;
      }
    }
    return maxPoint;
  }

  // TODO: Create a stub for totalDistance()
  public double totalDistance() {
    if (points == null) {
      throw new GPSException("No data in the track!");
    }
    if (points.size() < 2) {
      throw new GPSException("There is no enough data in the track!");
    }
    double totalDistance = 0;
    Point prevPoint = null;
    for (Point currPoint : points) {
      if (prevPoint != null) {
        double distance = Point.greatCircleDistance(prevPoint, currPoint);
        totalDistance += distance;
      }
      prevPoint = currPoint;
    }
    return totalDistance;
  }

  // TODO: Create a stub for averageSpeed()
  public double averageSpeed() {
    if (points == null) {
      throw new GPSException("No data in the track!");
    }
    if (points.size() < 2) {
      throw new GPSException("There is no enough data in the track!");
    }
    Point firstPoint = points.get(0);
    Point lastPoint = points.get(points.size() - 1);
    double timeDiff = ChronoUnit.SECONDS.between(firstPoint.getTime(), lastPoint.getTime());
    return this.totalDistance() / timeDiff;
  }
}
