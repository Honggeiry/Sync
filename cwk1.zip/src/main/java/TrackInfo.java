import java.io.FileNotFoundException;

/**
 * Program to provide information on a GPS track stored in a file.
 *
 * @author YOUR NAME HERE
 */
public class TrackInfo {
  public static void main(String[] args) {
    // TODO: Implement TrackInfo application here
    if (args.length == 0) {
      System.err.println("Error: no filename provided");
      System.exit(0);
    }

    String filename = args[0];

    try {
      Track track = new Track(filename);
      System.out.printf("%d points in track\n", track.size());
      System.out.println("Lowest point is " + track.lowestPoint());
      System.out.println("Highest point is " + track.highestPoint());
      System.out.printf("Total distance = %.3f km\n", track.totalDistance() / 1000.0);
      System.out.printf("Average speed = %.3f m/s\n", track.averageSpeed());
    } catch (FileNotFoundException e) {
      System.err.println("Error: file not found - " + filename);
      System.exit(-1);
    } catch (GPSException e) {
      System.err.println("Error: " + e.getMessage());
      System.exit(-1);
    }
  }
}
